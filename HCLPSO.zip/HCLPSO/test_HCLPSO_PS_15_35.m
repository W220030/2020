
clear all;
clc;

check_vel1=[];
check_vel2=[];
position=[];
value=[];
iteration=[];
num_FES=[];
result=[];
Error=[];
load Bounds;

for i=1:5% problem
    fprintf('Problem =\t %d\n',i);
    for j=1:30 % runs
        fprintf('run =\t %d\n',j)
        [check_vel1,check_vel2,position(i,j,:), value(i,j),iteration(i,j),num_FES(i,j),result(i,j,:),Error(i,j)]=HCLPSO_PS_15_35(40,Bounds(i,:),30,7500,300000,i);      
    end 
    file_name= [ 'HCLPSO_PS_15_35_',num2str(i),'_30D_30runs.mat'];
    save (file_name);   
end